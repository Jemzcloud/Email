"use client"

import { useState, useEffect, createContext, useContext } from "react"
import { createPortal } from "react-dom"

const TOAST_LIMIT = 5
const TOAST_REMOVE_DELAY = 5000

export const ToastContext = createContext({})

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([])
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
    return () => setIsMounted(false)
  }, [])

  const toast = ({ ...props }) => {
    const id = Math.random().toString(36).substring(2, 9)
    const newToast = { id, ...props }

    setToasts((prevToasts) => [...prevToasts, newToast])

    return {
      id,
      dismiss: () => dismissToast(id),
      update: (props) => updateToast(id, props),
    }
  }

  const dismissToast = (id) => {
    setToasts((prevToasts) => prevToasts.filter((toast) => toast.id !== id))
  }

  const updateToast = (id, props) => {
    setToasts((prevToasts) => prevToasts.map((toast) => (toast.id === id ? { ...toast, ...props } : toast)))
  }

  useEffect(() => {
    if (toasts.length > TOAST_LIMIT) {
      const toRemove = toasts.slice(0, toasts.length - TOAST_LIMIT)
      toRemove.forEach((toast) => dismissToast(toast.id))
    }
  }, [
    toasts,
    dismissToast,
  ]), // Added dismissToast to dependencies
    useEffect(() => {
      const timeouts = []

      toasts.forEach((toast) => {
        const timeout = setTimeout(() => {
          dismissToast(toast.id)
        }, TOAST_REMOVE_DELAY)

        timeouts.push(timeout)
      })

      return () => {
        timeouts.forEach((timeout) => clearTimeout(timeout))
      }
    }, [toasts, dismissToast]) // Added dismissToast to dependencies

  return (
    <ToastContext.Provider value={{ toasts, toast, dismissToast }}>
      {children}
      {isMounted &&
        createPortal(
          <div className="fixed top-0 right-0 z-50 flex flex-col gap-2 p-4 max-w-md w-full">
            {toasts.map((toast) => (
              <div
                key={toast.id}
                className={`bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 transition-all duration-300 animate-in fade-in slide-in-from-right-5 ${
                  toast.variant === "destructive" ? "border-l-4 border-red-500" : "border-l-4 border-green-500"
                }`}
              >
                {toast.title && <h3 className="font-semibold">{toast.title}</h3>}
                {toast.description && <p className="text-sm text-gray-500 dark:text-gray-400">{toast.description}</p>}
                <button
                  onClick={() => dismissToast(toast.id)}
                  className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
            ))}
          </div>,
          document.body,
        )}
    </ToastContext.Provider>
  )
}

export const useToast = () => {
  const context = useContext(ToastContext)

  if (context === undefined) {
    throw new Error("useToast must be used within a ToastProvider")
  }

  return context
}


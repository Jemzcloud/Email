"use client"

import type React from "react"

import { ThemeProvider } from "@/components/theme-provider"
import { ToastProvider } from "@/components/ui/use-toast"

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider attribute="class" defaultTheme="light">
      <ToastProvider>{children}</ToastProvider>
    </ThemeProvider>
  )
}


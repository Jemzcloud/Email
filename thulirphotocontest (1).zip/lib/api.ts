// This is a mock implementation for demonstration purposes
// In a real application, you would use a proper database and storage system

interface Image {
  id: string
  title: string
  description: string
  url: string
  createdAt: string
}

interface Vote {
  id: string
  deviceId: string // Changed from userId to deviceId
  imageId: string
  createdAt: string
}

// Mock database
let images: Image[] = [
  {
    id: "1",
    title: "Campus View",
    description: "Beautiful view of the campus during sunset",
    url: "/placeholder.svg?height=600&width=600",
    createdAt: new Date().toISOString(),
  },
  {
    id: "2",
    title: "Agricultural Field",
    description: "Students working in the agricultural field",
    url: "/placeholder.svg?height=600&width=600",
    createdAt: new Date().toISOString(),
  },
]

// Mock votes database
let votes: Vote[] = []

export async function getImages(): Promise<Image[]> {
  // Simulate network request
  await new Promise((resolve) => setTimeout(resolve, 500))
  return [...images]
}

export async function getImage(id: string): Promise<Image> {
  // Simulate network request
  await new Promise((resolve) => setTimeout(resolve, 300))

  const image = images.find((img) => img.id === id)
  if (!image) {
    throw new Error("Image not found")
  }

  return { ...image }
}

export async function uploadImage(file: File, title: string, description: string): Promise<Image> {
  // Simulate network request and file upload
  await new Promise((resolve) => setTimeout(resolve, 1500))

  // In a real app, you would upload the file to storage and get a URL
  // Here we're just using a placeholder
  const newImage: Image = {
    id: String(images.length + 1),
    title,
    description,
    url: "/placeholder.svg?height=600&width=600",
    createdAt: new Date().toISOString(),
  }

  images.push(newImage)
  return newImage
}

export async function voteForImage(deviceId: string, imageId: string): Promise<Vote> {
  // Simulate network request
  await new Promise((resolve) => setTimeout(resolve, 300))

  // Check if device has already voted for any image
  if (votes.some((vote) => vote.deviceId === deviceId)) {
    throw new Error("Device has already voted")
  }

  // Check if image exists
  if (!images.some((img) => img.id === imageId)) {
    throw new Error("Image not found")
  }

  // Add vote
  const newVote: Vote = {
    id: String(votes.length + 1),
    deviceId,
    imageId,
    createdAt: new Date().toISOString(),
  }

  votes.push(newVote)
  return newVote
}

export async function hasVoted(deviceId: string): Promise<string | null> {
  // Simulate network request
  await new Promise((resolve) => setTimeout(resolve, 100))

  const vote = votes.find((v) => v.deviceId === deviceId)
  return vote ? vote.imageId : null
}

export async function getImageVotes(imageId: string): Promise<Vote[]> {
  // Simulate network request
  await new Promise((resolve) => setTimeout(resolve, 300))

  return votes.filter((vote) => vote.imageId === imageId)
}

export async function deleteImage(id: string): Promise<{ success: boolean }> {
  // Simulate network request
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Remove image
  images = images.filter((img) => img.id !== id)

  // Remove associated votes
  votes = votes.filter((vote) => vote.imageId !== id)

  return { success: true }
}


import { NextResponse } from "next/server"
import { voteForImage } from "@/lib/api"

export async function POST(request: Request) {
  try {
    const { imageId, deviceId } = await request.json()

    if (!imageId || !deviceId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Use the device ID as the user ID for voting
    const vote = await voteForImage(deviceId, imageId)

    return NextResponse.json({ success: true, vote })
  } catch (error: any) {
    console.error("Error recording vote:", error)
    return NextResponse.json({ error: error.message || "Failed to record vote" }, { status: 500 })
  }
}


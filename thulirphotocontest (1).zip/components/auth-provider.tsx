"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import { signIn, signOut, getCurrentUser } from "@/lib/auth"
import { AuthDialog } from "@/components/auth-dialog"

interface User {
  id: string
  email: string
  name: string
  role: "admin" | "user"
}

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<User>
  logout: () => Promise<void>
  openAuthDialog: () => void
  closeAuthDialog: () => void
  isAdmin: boolean
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [showAuthDialog, setShowAuthDialog] = useState(false)

  useEffect(() => {
    async function loadUser() {
      try {
        const currentUser = await getCurrentUser()
        setUser(currentUser)
      } catch (error) {
        console.error("Failed to load user:", error)
      } finally {
        setLoading(false)
      }
    }

    loadUser()
  }, [])

  const login = async (email: string, password: string) => {
    try {
      const user = await signIn(email, password)
      setUser(user)
      return user
    } catch (error) {
      throw error
    }
  }

  const logout = async () => {
    try {
      await signOut()
      setUser(null)
    } catch (error) {
      console.error("Failed to sign out:", error)
    }
  }

  const openAuthDialog = () => {
    setShowAuthDialog(true)
  }

  const closeAuthDialog = () => {
    setShowAuthDialog(false)
  }

  const value = {
    user,
    loading,
    login,
    logout,
    openAuthDialog,
    closeAuthDialog,
    isAdmin: user?.role === "admin",
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
      {showAuthDialog && <AuthDialog onClose={closeAuthDialog} />}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === null) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}


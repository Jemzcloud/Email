"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { getImages, getImageVotes } from "@/lib/api"
import { ArrowLeft, Heart, LogOut } from "lucide-react"

interface Image {
  id: string
  title: string
  description: string
  url: string
  createdAt: string
  votes?: any[]
}

export default function AdminPage() {
  const [images, setImages] = useState<Image[]>([])
  const [loading, setLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    // Check if user is admin
    const checkAdminAuth = () => {
      if (typeof window !== "undefined") {
        const isAdminAuth = localStorage.getItem("thulir_admin_auth") === "true"
        setIsAdmin(isAdminAuth)

        if (!isAdminAuth) {
          router.push("/admin-login")
        }
      }
    }

    checkAdminAuth()

    async function loadImages() {
      try {
        const data = await getImages()

        // Get vote counts for each image
        const imagesWithVotes = await Promise.all(
          data.map(async (image) => {
            const votes = await getImageVotes(image.id)
            return { ...image, votes }
          }),
        )

        setImages(imagesWithVotes)
        setLoading(false)
      } catch (error) {
        console.error("Failed to load images:", error)
        toast({
          title: "Error",
          description: "Failed to load images. Please try again.",
          variant: "destructive",
        })
        setLoading(false)
      }
    }

    if (isAdmin) {
      loadImages()
    }
  }, [router, toast, isAdmin])

  const handleLogout = () => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("thulir_admin_auth")
      router.push("/")

      toast({
        title: "Logged out",
        description: "You have been logged out successfully.",
      })
    }
  }

  if (!isAdmin) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Link href="/" className="mr-4">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        </div>
        <Button variant="outline" onClick={handleLogout}>
          <LogOut className="h-4 w-4 mr-2" />
          Logout
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Voting Results</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : images.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-lg">No images available yet.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {images
                .sort((a, b) => (b.votes?.length || 0) - (a.votes?.length || 0))
                .map((image, index) => (
                  <div key={image.id} className="flex items-center gap-4 border-b pb-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold">
                      {index + 1}
                    </div>
                    <div className="relative h-20 w-20 flex-shrink-0 overflow-hidden rounded-md">
                      <Image src={image.url || "/placeholder.svg"} alt={image.title} fill className="object-cover" />
                    </div>
                    <div className="flex-grow">
                      <h3 className="font-semibold">{image.title}</h3>
                      <p className="text-sm text-gray-500 line-clamp-1">{image.description}</p>
                    </div>
                    <div className="flex items-center gap-1 text-lg font-bold">
                      <Heart className="h-5 w-5 fill-red-500 text-red-500" />
                      {image.votes?.length || 0}
                    </div>
                  </div>
                ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}


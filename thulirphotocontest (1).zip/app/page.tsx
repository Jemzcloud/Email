import Image from "next/image"
import Link from "next/link"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between relative overflow-hidden">
      <div className="w-full h-screen relative overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <Image src="/IMG-20250227-WA0013.png" alt="Background" fill className="object-cover" priority />
        </div>

        {/* Overlay for better text readability */}
        <div className="absolute inset-0 bg-black/20"></div>

        {/* Content container */}
        <div className="relative z-10 flex flex-col items-center justify-between h-full px-4 py-6">
          {/* Header */}
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Image src="/logo.svg" alt="Sethu Institute Logo" width={50} height={50} className="mr-2" />
              <h1 className="text-white font-extrabold text-xl leading-tight">SETHU INSTITUTE OF TECHNOLOGY</h1>
            </div>
            <p className="text-white text-xs font-semibold mb-1">
              AN AUTONOMOUS INSTITUTION ACCREDITED WITH &apos;A++&apos; GRADE BY NAAC
            </p>
            <p className="text-white text-xs font-semibold">PULLOOR, KARIAPATTI - 626 115</p>
          </div>

          {/* Department Name */}
          <div className="text-center my-4">
            <h2 className="text-white font-bold text-2xl leading-tight">
              DEPARTMENT OF AGRICULTURAL
              <br />
              ENGINEERING
            </h2>
          </div>

          {/* Event Name */}
          <div className="text-center my-4">
            <h2 className="text-yellow-300 font-bold text-7xl" style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.5)" }}>
              Thulir
            </h2>
            <h3 className="text-yellow-300 font-bold text-5xl" style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.5)" }}>
              2k25
            </h3>
          </div>

          {/* Behind the Lens */}
          <div className="text-center my-4">
            <h2
              className="text-cyan-400 font-bold italic text-5xl"
              style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.5)" }}
            >
              Behind
            </h2>
            <div className="flex items-center justify-center">
              <h3
                className="text-yellow-300 font-bold text-3xl mx-2"
                style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.5)" }}
              >
                THE
              </h3>
            </div>
            <h2
              className="text-red-500 font-bold italic text-6xl"
              style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.5)" }}
            >
              Lens
            </h2>
          </div>

          {/* Camera and Video Camera Icons */}
          <div className="flex justify-between w-full px-8 my-4">
            <div className="w-24 h-24 opacity-80">
              <svg
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="w-full h-full text-white"
              >
                <path
                  d="M12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16Z"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M3 16.8V7.2C3 6.0799 3 5.51984 3.21799 5.09202C3.40973 4.71569 3.71569 4.40973 4.09202 4.21799C4.51984 4 5.0799 4 6.2 4H17.8C18.9201 4 19.4802 4 19.908 4.21799C20.2843 4.40973 20.5903 4.71569 20.782 5.09202C21 5.51984 21 6.0799 21 7.2V16.8C21 17.9201 21 18.4802 20.782 18.908C20.5903 19.2843 20.2843 19.5903 19.908 19.782C19.4802 20 18.9201 20 17.8 20H6.2C5.0799 20 4.51984 20 4.09202 19.782C3.71569 19.5903 3.40973 19.2843 3.21799 18.908C3 18.4802 3 17.9201 3 16.8Z"
                  stroke="currentColor"
                  strokeWidth="1.5"
                />
                <path
                  d="M17.5 7.5H17.509"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <div className="w-24 h-24 opacity-80">
              <svg
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="w-full h-full text-white"
              >
                <path
                  d="M22 8.93137C22 8.32555 22 8.02265 21.8802 7.88238C21.7763 7.76068 21.6203 7.69609 21.4608 7.70865C21.2769 7.72312 21.0627 7.93731 20.6343 8.36569L17 12L20.6343 15.6343C21.0627 16.0627 21.2769 16.2769 21.4608 16.2914C21.6203 16.3039 21.7763 16.2393 21.8802 16.1176C22 15.9774 22 15.6744 22 15.0686V8.93137Z"
                  stroke="currentColor"
                  strokeWidth="1.5"
                />
                <path
                  d="M2 7.8C2 6.11984 2 5.27976 2.32698 4.63803C2.6146 4.07354 3.07354 3.6146 3.63803 3.32698C4.27976 3 5.11984 3 6.8 3H13.2C14.8802 3 15.7202 3 16.362 3.32698C16.9265 3.6146 17.3854 4.07354 17.673 4.63803C18 5.27976 18 6.11984 18 7.8V16.2C18 17.8802 18 18.7202 17.673 19.362C17.3854 19.9265 16.9265 20.3854 16.362 20.673C15.7202 21 14.8802 21 13.2 21H6.8C5.11984 21 4.27976 21 3.63803 20.673C3.07354 20.3854 2.6146 19.9265 2.32698 19.362C2 18.7202 2 17.8802 2 16.2V7.8Z"
                  stroke="currentColor"
                  strokeWidth="1.5"
                />
              </svg>
            </div>
          </div>

          {/* Vote Button and Admin Login */}
          <div className="flex flex-col items-center gap-4 mb-8">
            <Link
              href="/gallery"
              className="bg-yellow-400 hover:bg-yellow-500 text-black text-3xl font-bold py-4 px-8 rounded-full shadow-lg transition-all duration-300"
            >
              Click For vote
            </Link>
            <Link
              href="/admin-login"
              className="bg-transparent hover:bg-white/20 text-white text-sm font-semibold py-2 px-4 rounded-full transition-all duration-300"
            >
              Admin Login
            </Link>
          </div>
        </div>
      </div>
    </main>
  )
}


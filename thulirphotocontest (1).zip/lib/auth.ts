// This is a mock implementation for demonstration purposes
// In a real application, you would use a proper authentication system

const STORAGE_KEY = "thulir_auth_user"

// Mock user database
const users = [
  {
    id: "1",
    email: "admin@example.com",
    password: "admin123", // In a real app, passwords would be hashed
    name: "Admin User",
    role: "admin",
  },
  {
    id: "2",
    email: "user@example.com",
    password: "user123",
    name: "Regular User",
    role: "user",
  },
]

interface User {
  id: string
  email: string
  name: string
  role: "admin" | "user"
}

interface UserWithPassword extends User {
  password: string
}

export async function signIn(email: string, password: string): Promise<User> {
  // Simulate network request
  await new Promise((resolve) => setTimeout(resolve, 500))

  const user = users.find((user) => user.email === email && user.password === password)

  if (!user) {
    throw new Error("Invalid credentials")
  }

  // Store user in localStorage (in a real app, you'd use cookies or tokens)
  const { password: _, ...userWithoutPassword } = user
  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(userWithoutPassword))
  }

  return userWithoutPassword
}

export async function signOut(): Promise<void> {
  // Simulate network request
  await new Promise((resolve) => setTimeout(resolve, 300))

  if (typeof window !== "undefined") {
    localStorage.removeItem(STORAGE_KEY)
  }
}

export async function getCurrentUser(): Promise<User | null> {
  // Simulate network request
  await new Promise((resolve) => setTimeout(resolve, 300))

  if (typeof window === "undefined") {
    return null
  }

  const userJson = localStorage.getItem(STORAGE_KEY)
  if (!userJson) {
    return null
  }

  return JSON.parse(userJson)
}

export async function registerUser(email: string, password: string, name: string): Promise<User> {
  // Simulate network request
  await new Promise((resolve) => setTimeout(resolve, 800))

  // Check if user already exists
  if (users.some((user) => user.email === email)) {
    throw new Error("User already exists")
  }

  // Create new user
  const newUser: UserWithPassword = {
    id: String(users.length + 1),
    email,
    password,
    name,
    role: "user",
  }

  // Add to mock database
  users.push(newUser)

  // Return user without password
  const { password: _, ...userWithoutPassword } = newUser
  return userWithoutPassword
}


"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { getImages } from "@/lib/api"
import { ArrowLeft, Heart } from "lucide-react"

interface Image {
  id: string
  title: string
  description: string
  url: string
  createdAt: string
}

// Local storage keys
const VOTED_IMAGE_KEY = "thulir_voted_image"
const DEVICE_ID_KEY = "thulir_device_id"

export default function GalleryPage() {
  const [images, setImages] = useState<Image[]>([])
  const [loading, setLoading] = useState(true)
  const [votedImageId, setVotedImageId] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    // Load voted image from localStorage
    const loadVotedImage = () => {
      if (typeof window !== "undefined") {
        const savedVote = localStorage.getItem(VOTED_IMAGE_KEY)
        if (savedVote) {
          setVotedImageId(savedVote)
        }
      }
    }

    async function loadImages() {
      try {
        const data = await getImages()
        setImages(data)
        loadVotedImage()
        setLoading(false)
      } catch (error) {
        console.error("Failed to load images:", error)
        toast({
          title: "Error",
          description: "Failed to load images. Please try again.",
          variant: "destructive",
        })
        setLoading(false)
      }
    }

    loadImages()
  }, [toast])

  const handleVote = async (imageId: string) => {
    if (votedImageId) {
      toast({
        title: "Already voted",
        description: "You can only vote for one photo in this contest.",
        variant: "destructive",
      })
      return
    }

    try {
      // Get or create device ID
      let deviceId = localStorage.getItem(DEVICE_ID_KEY)
      if (!deviceId) {
        deviceId = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
        localStorage.setItem(DEVICE_ID_KEY, deviceId)
      }

      // Record vote in the backend
      await fetch("/api/vote", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          imageId,
          deviceId,
        }),
      })

      // Save vote in localStorage
      localStorage.setItem(VOTED_IMAGE_KEY, imageId)
      setVotedImageId(imageId)

      toast({
        title: "Vote recorded",
        description: "Thank you for your vote!",
      })
    } catch (error) {
      console.error("Failed to vote:", error)
      toast({
        title: "Error",
        description: "Failed to record your vote. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <Link href="/" className="mr-4">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-6 w-6" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Photo Gallery</h1>
      </div>

      {votedImageId && (
        <div className="mb-6 p-4 bg-yellow-100 border border-yellow-400 rounded-lg">
          <p className="text-yellow-800">
            You have already cast your vote. Thank you for participating in the contest!
          </p>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      ) : images.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-lg">No images available yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {images.map((image) => (
            <Card key={image.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="relative aspect-square">
                  <Image
                    src={image.url || "/placeholder.svg"}
                    alt={image.title || "Contest photo"}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-lg mb-2">{image.title}</h3>
                  <p className="text-sm text-gray-600 mb-4">{image.description}</p>
                  <Button
                    onClick={() => handleVote(image.id)}
                    disabled={votedImageId !== null}
                    className="w-full"
                    variant={votedImageId === image.id ? "outline" : "default"}
                  >
                    <Heart className={`mr-2 h-4 w-4 ${votedImageId === image.id ? "fill-primary" : ""}`} />
                    {votedImageId === image.id ? "Your Vote" : votedImageId ? "Already Voted" : "Vote"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

